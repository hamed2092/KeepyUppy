const express = require('express');
const { Pool } = require('pg');
const app = express();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

app.use(express.json());

// یک مسیر نمونه برای تست سلامت سرور
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running on Vercel!' });
});

// مسیر اصلی برای ذخیره امتیاز یا اطلاعات بازی
app.post('/api/save-score', async (req, res) => {
  const { userId, score } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO scores (user_id, score) VALUES ($1, $2) ON CONFLICT (user_id) DO UPDATE SET score = EXCLUDED.score RETURNING *',
      [userId, score]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = app;
